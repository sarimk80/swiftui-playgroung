import SwiftUI

struct ContentView: View {
    
    var body: some View{
        
        VStack{
            header
                .headerTextStyle()
            Text("Hello world!")
                .modifier(BodyText())
                
        }
        
        
    }
}

@ViewBuilder var header : some View{
    Text("Header")
}

extension View {
    func headerTextStyle() -> some View{
        self
            .padding()
            .font(.title)
            .foregroundColor(.green)
    }
}



struct BodyText : ViewModifier {
    func body(content : Content) -> some View {
        content
            .padding()
            .font(.headline)
            .background(.blue, in: RoundedRectangle(cornerSize: CGSize(width: 20, height: 20), style: .circular))
    }
}







