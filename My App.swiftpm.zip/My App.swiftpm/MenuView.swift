import SwiftUI

struct MenuView: View {
    var body: some View {
        VStack{
            Menu("Menu 1") { 
                Button { 
                    print("Menu 1 click 1")
                } label: { 
                    Text("Button 1")
                }
                
                Button { 
                    print("Menu 1 click 2")
                } label: { 
                    Text("Button 2")
                }
                
                Button { 
                    print("Menu 1 click 3")
                } label: { 
                    Text("Button 3")
                }
                
                Menu { 
                    Button { 
                        print("Menu 2 click 4")
                    } label: { 
                        Text("Button 4")
                    }
                } label: { 
                    Text("Menu 2")
                }
                
                
            }
            
            
            Menu { 
                Button { 
                    print("Menu 2 click 4")
                } label: { 
                    Text("Button 4")
                }
            } label: { 
                Image(systemName: "line.3.horizontal")
                    .font(.title)
            }
            .padding()
            
            
            
            Menu { 
                Button { 
                    print("Menu 2 click 4")
                } label: { 
                    Text("Button 4")
                }
            } label: { 
                Label("Primary Action", systemImage: "line.3.horizontal")
                    .font(.title)
            } primaryAction: { 
                print("Primary Action")
            }
            .menuStyle(.borderlessButton)
            
            
            
            
        }
    }
}


